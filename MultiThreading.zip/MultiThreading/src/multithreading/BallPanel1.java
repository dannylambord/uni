/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreading;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author danny
 */
class BallPanel1 extends JPanel {
    
    private static final int WIDTH = 20;
    private static final int HEIGHT = 30;
    

   
    
}
